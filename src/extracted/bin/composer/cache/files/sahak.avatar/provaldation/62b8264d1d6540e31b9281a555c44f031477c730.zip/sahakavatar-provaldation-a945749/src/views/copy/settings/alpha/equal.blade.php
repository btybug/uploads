<div class="form-group m-b-10 clearfix">
    <label class="col-md-4 control-label label-bold text-center" for="textinput">Equal to</label>
    <div class="col-md-8">
        <input name="equal" type="text" min="1" data-rule="equal" class="form-control input-md">
    </div>
</div>