<label class="col-md-3 control-label label-bold" for="selectbasic">Select Rule</label>
<div class="col-md-9">
    <select id="pro_validation_rules" name="pro_validation_rule" class="form-control">
        <option value="0">Select Rule</option>
        <option value="contain">Contain</option>
        <option value="not_contain">Not Contain</option>
    </select>
</div>