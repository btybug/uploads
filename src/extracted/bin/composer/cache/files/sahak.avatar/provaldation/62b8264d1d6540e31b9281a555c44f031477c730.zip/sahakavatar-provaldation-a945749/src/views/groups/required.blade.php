<label class="col-md-3 control-label label-bold" for="selectbasic">Select Required rule</label>
<div class="col-md-9">
    <select id="pro_validation_rules" name="pro_validation_rule" class="form-control">
        <option value="0">Select Rule</option>
        <option value="required">required</option>
        <option value="required_if">Required if</option>
        <option value="required_unless">Required unless</option>
        <option value="required_with">Required with</option>
        <option value="required_with_all">Required with all</option>
        <option value="required_without">Required without</option>
        <option value="required_without_all">Required without all</option>
    </select>
</div>