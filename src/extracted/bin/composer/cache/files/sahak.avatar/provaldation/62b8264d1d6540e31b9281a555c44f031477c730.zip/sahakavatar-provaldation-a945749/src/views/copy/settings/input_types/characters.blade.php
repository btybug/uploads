<h4>Characters</h4>
<p>The field under validation must be entirely  characters like ($%^&*).</p>