<?php

addProvider('Sahak\Validator\Providers\ModuleServiceProvider');


