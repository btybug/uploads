<?php Avatar\ProValid\tests;

/**
 * Created by PhpStorm.
 * User: menq
 * Date: 7/7/17
 * Time: 1:04 AM
 */
class ProvalidatorTests
{
    public function test()
    {
        return "OK";

}
}