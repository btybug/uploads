<h4>alpha_num</h4>
<p>The field under validation must be entirely alpha-numeric characters.</p>