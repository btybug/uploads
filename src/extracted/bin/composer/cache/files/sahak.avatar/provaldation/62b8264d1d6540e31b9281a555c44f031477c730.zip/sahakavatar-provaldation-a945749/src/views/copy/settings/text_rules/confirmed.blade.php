<div class="form-group m-b-10 clearfix">
    <label class="col-md-4 control-label  label-bold text-center" for="textinput">Other Field name</label>
    <div class="col-md-8">
        <input name="contain" type="text"  data-rule="confirmed" class="form-control input-md">
    </div>
</div>