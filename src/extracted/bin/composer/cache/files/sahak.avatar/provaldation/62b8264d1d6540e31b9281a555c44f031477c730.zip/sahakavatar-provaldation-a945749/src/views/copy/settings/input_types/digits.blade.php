<div class="form-group m-b-10 clearfix">
    <label class="col-md-4 control-label label-bold text-center" for="textinput">Digits</label>
    <div class="col-md-8">
        <input name="textinput" type="number" min="1" data-rule="digits" class="form-control input-md">
    </div>
</div>
<h4>digits:<em>value</em></h4>
<p>The field under validation must be <em>numeric</em> and must have an exact length of <em>value</em>.</p>