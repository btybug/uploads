<!-- Submit input-->

{{ Form::submit('Save', array('class' => 'btn')) }}
