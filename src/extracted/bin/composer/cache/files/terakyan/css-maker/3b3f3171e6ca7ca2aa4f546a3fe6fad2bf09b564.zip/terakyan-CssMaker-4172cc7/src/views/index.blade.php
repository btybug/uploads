@extends('cms::layouts.admin')
@section('content')
    <div class="main_lay_cont">
        <div class="row for_title_row">
            <h1 class="text-center">Css Maker Control</h1>
        </div>
    </div>

@stop
@section('CSS')
@stop
@section('JS')
@stop
