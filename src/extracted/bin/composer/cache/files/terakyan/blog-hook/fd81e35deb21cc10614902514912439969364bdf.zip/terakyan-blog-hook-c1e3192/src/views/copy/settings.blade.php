@extends('cms::layouts.admin')

@section('content')
@stop
@section('CSS')

@stop
@section('JS')
@stop