<h4>alpha_dash</h4>
<p>The field under validation may have alpha-numeric characters, as well as dashes and underscores.</p>
