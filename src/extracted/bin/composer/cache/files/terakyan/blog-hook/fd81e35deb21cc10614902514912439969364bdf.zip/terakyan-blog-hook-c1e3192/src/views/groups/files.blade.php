<label class="col-md-3 control-label label-bold" for="selectbasic">Select File Rules</label>
<div class="col-md-9">
    <select id="pro_validation_rules" name="pro_validation_rule" class="form-control">
        <option value="0">Select Rule</option>
        <option value="file">File</option>
        <option value="image">image</option>
        <option value="mimetypes">MIME Types</option>
        <option value="mimes">MIME Type By File Extension</option>
    </select>
</div>