<h4>timezone</h4>
<p>The field under validation must be a valid timezone identifier according to the <code class=" language-php">timezone_identifiers_list</code> PHP function.</p>