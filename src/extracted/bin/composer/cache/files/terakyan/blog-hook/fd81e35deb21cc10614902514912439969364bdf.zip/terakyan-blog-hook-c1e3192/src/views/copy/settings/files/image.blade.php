<h4>image</h4>
<p>The file under validation must be an image (jpeg, png, bmp, gif, or svg)</p>