<label class="col-md-3 control-label label-bold" for="selectbasic">Select Rule For any type</label>
<div class="col-md-9">
    <select id="pro_validation_rules" name="pro_validation_rule" class="form-control">
        <option value="0">Select Rule</option>
        <option value="present">Present</option>
        <option value="required">Required</option>
        <option value="nullable">Nullable</option>
        <option value="in">In</option>
    </select>
</div>