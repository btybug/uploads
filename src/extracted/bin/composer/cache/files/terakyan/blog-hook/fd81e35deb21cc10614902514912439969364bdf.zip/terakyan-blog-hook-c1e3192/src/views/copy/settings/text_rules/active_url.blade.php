<h4>active_url</h4>
<p>The field under validation must have a valid A or AAAA record according to the <code class=" language-php">dns_get_record</code> PHP function.</p>