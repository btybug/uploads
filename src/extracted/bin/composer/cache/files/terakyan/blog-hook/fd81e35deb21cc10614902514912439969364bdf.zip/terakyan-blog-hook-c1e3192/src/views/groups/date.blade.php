<label class="col-md-3 control-label label-bold" for="selectbasic">Select Date Rule</label>
<div class="col-md-9">
    <select id="pro_validation_rules" name="pro_validation_rule" class="form-control">
        <option value="0">Select Rule</option>
        <option value="date">Date</option>
        <option value="date_format">Date Format</option>
        <option value="after">After Date</option>
        <option value="after_or_equal">After or Equal</option>
        <option value="before">Before Date</option>
        <option value="before_or_equal">Before or Equal</option>
        <option value="timezone">Timezone</option>
    </select>
</div>