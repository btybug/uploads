<h4>alpha</h4>
<p>The field under validation must be entirely alphabetic characters.</p>