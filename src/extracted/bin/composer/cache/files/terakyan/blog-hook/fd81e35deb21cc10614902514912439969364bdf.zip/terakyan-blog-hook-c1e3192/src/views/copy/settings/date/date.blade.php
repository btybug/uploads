<h4>date</h4>
<p>The field under validation must be a valid date according to the <code class=" language-php">strtotime</code> PHP function.</p>